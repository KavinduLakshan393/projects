"use client";

import Image from "next/image";
import Link from "next/link";
import { signOut } from "next-auth/react";
import { usePathname } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

interface TopHeaderProps {
  avatarUrl?: string | null;
  userName?: string | null;
  userEmail?: string | null;
}

const PAGE_COPY: Record<string, { title: string; eyebrow: string }> = {
  "/dashboard": {
    title: "Dashboard",
    eyebrow: "Today at a glance",
  },
  "/attendance": {
    title: "Attendance",
    eyebrow: "Shift history and records",
  },
  "/salary": {
    title: "Salary",
    eyebrow: "Earnings and overtime report",
  },
  "/settings": {
    title: "Settings",
    eyebrow: "Shift, pay, and app preferences",
  },
};

function getInitial(name?: string | null, email?: string | null) {
  const source = name?.trim() || email?.trim() || "User";
  return source.charAt(0).toUpperCase();
}

function getPageCopy(pathname: string) {
  const matchedRoute = Object.keys(PAGE_COPY)
    .sort((a, b) => b.length - a.length)
    .find((route) => pathname === route || pathname.startsWith(`${route}/`));

  return matchedRoute ? PAGE_COPY[matchedRoute] : PAGE_COPY["/dashboard"];
}

function BrandMark() {
  return (
    <Link href="/dashboard" className="flex items-center gap-2" aria-label="ShiftSync dashboard">
      <span className="flex h-9 w-9 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-sm">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="2" />
          <path d="M12 7v5l3 2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
      <span className="text-sm font-black tracking-[0.18em] text-foreground">
        SHIFT<span className="text-primary">SYNC</span>
      </span>
    </Link>
  );
}

export function TopHeader({ avatarUrl, userName, userEmail }: TopHeaderProps) {
  const pathname = usePathname();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const page = useMemo(() => getPageCopy(pathname), [pathname]);

  useEffect(() => {
    document.body.style.overflow = isMenuOpen ? "hidden" : "";

    return () => {
      document.body.style.overflow = "";
    };
  }, [isMenuOpen]);

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-border bg-background/82 backdrop-blur-xl">
        <div className="flex h-16 items-center justify-between gap-4 px-4 sm:px-6 md:px-8 lg:px-10">
          <div className="min-w-0">
            <div className="md:hidden">
              <BrandMark />
            </div>

            <div className="hidden min-w-0 md:block">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                {page.eyebrow}
              </p>
              <h1 className="mt-0.5 truncate text-xl font-bold tracking-tight text-foreground">
                {page.title}
              </h1>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsMenuOpen(true)}
            className="flex items-center gap-3 rounded-2xl border border-border bg-surface px-2 py-2 shadow-sm transition hover:border-primary/40 hover:bg-surface-elevated focus-visible:outline-primary"
            aria-label="Open account menu"
            aria-haspopup="dialog"
          >
            <span className="hidden max-w-44 text-right md:block">
              <span className="block truncate text-sm font-semibold text-foreground">
                {userName ?? "ShiftSync User"}
              </span>
              <span className="block truncate text-xs text-muted-foreground">
                {userEmail ?? "Signed in"}
              </span>
            </span>

            <span className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-2xl bg-primary text-sm font-bold text-primary-foreground">
              {avatarUrl ? (
                <Image
                  src={avatarUrl}
                  alt={userName ?? "User avatar"}
                  width={40}
                  height={40}
                  className="h-full w-full object-cover"
                />
              ) : (
                getInitial(userName, userEmail)
              )}
            </span>
          </button>
        </div>
      </header>

      {isMenuOpen ? (
        <>
          <button
            type="button"
            className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-sm"
            aria-label="Close account menu"
            onClick={() => setIsMenuOpen(false)}
          />

          <section
            role="dialog"
            aria-modal="true"
            aria-label="Account menu"
            className="fixed inset-x-3 bottom-3 z-50 mx-auto max-w-md rounded-3xl border border-border bg-surface p-5 shadow-2xl md:bottom-auto md:left-auto md:right-8 md:top-20 md:mx-0 md:w-96"
          >
            <div className="mb-5 flex items-center gap-4">
              <span className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-2xl bg-primary text-lg font-bold text-primary-foreground">
                {avatarUrl ? (
                  <Image
                    src={avatarUrl}
                    alt={userName ?? "User avatar"}
                    width={56}
                    height={56}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  getInitial(userName, userEmail)
                )}
              </span>

              <div className="min-w-0">
                <p className="truncate text-base font-bold text-foreground">
                  {userName ?? "ShiftSync User"}
                </p>
                <p className="truncate text-sm text-muted-foreground">{userEmail ?? "Signed in"}</p>
              </div>
            </div>

            <div className="rounded-2xl border border-border bg-muted/40 p-4">
              <p className="text-sm font-semibold text-foreground">Account status</p>
              <p className="mt-1 text-sm leading-6 text-muted-foreground">
                Your attendance data is linked to this account. Sign out only when you are finished using this device.
              </p>
            </div>

            <div className="mt-5 grid gap-2">
              <Link
                href="/settings"
                onClick={() => setIsMenuOpen(false)}
                className="rounded-2xl px-4 py-3 text-sm font-semibold text-foreground transition hover:bg-muted"
              >
                Open settings
              </Link>

              <button
                type="button"
                onClick={async () => {
                  setIsMenuOpen(false);
                  await signOut({ callbackUrl: "/login" });
                }}
                className="rounded-2xl px-4 py-3 text-left text-sm font-semibold text-destructive transition hover:bg-destructive/10"
              >
                Sign out
              </button>
            </div>
          </section>
        </>
      ) : null}
    </>
  );
}
