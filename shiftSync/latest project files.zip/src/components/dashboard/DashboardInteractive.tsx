"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { clockIn, clockOut, getTodaySessions } from "@/app/actions/time";

type Session = {
  id: string;
  workDate: string;
  clockIn: Date | string;
  clockOut: Date | string | null;
  durationMinutes: number;
  regularHours: number | null;
  otHours: number | null;
  totalEarned: number | null;
  appliedRegularRate: number;
  appliedOtRate: number;
  autoClosed?: boolean;
  notes: string | null;
};

interface DashboardInteractiveProps {
  regularShiftHours: number;
  regularHourlyRate: number;
  otHourlyRate: number;
  currencySymbol: string;
}

function getLocalDateString() {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function getTimezoneOffsetMinutes() {
  return new Date().getTimezoneOffset();
}

function formatDateLabel(workDate: string) {
  return new Date(`${workDate}T00:00:00`).toLocaleDateString(undefined, {
    weekday: "long",
    month: "short",
    day: "numeric",
  });
}

function formatTime(value: Date | string | null) {
  if (!value) return "--:--";

  return new Date(value).toLocaleTimeString(undefined, {
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatDuration(totalSeconds: number) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function formatHours(hours: number) {
  return `${hours.toFixed(2)}h`;
}

function formatMoney(amount: number, symbol: string) {
  return `${symbol}${amount.toFixed(2)}`;
}

function normalizeSession(session: Session): Session {
  return {
    ...session,
    autoClosed: Boolean(session.autoClosed),
  };
}

function StatCard({
  label,
  value,
  note,
}: {
  label: string;
  value: string;
  note: string;
}) {
  return (
    <div className="rounded-3xl border border-border bg-surface p-5 shadow-sm">
      <p className="text-xs font-bold uppercase tracking-[0.18em] text-muted-foreground">{label}</p>
      <p className="mt-3 text-3xl font-black tracking-tight text-foreground tabular-nums">{value}</p>
      <p className="mt-1 text-sm text-muted-foreground">{note}</p>
    </div>
  );
}

export function DashboardInteractive({
  regularShiftHours,
  regularHourlyRate,
  otHourlyRate,
  currencySymbol,
}: DashboardInteractiveProps) {
  const safeRegularShiftHours = regularShiftHours > 0 ? regularShiftHours : 8;

  const [localDate, setLocalDate] = useState("");
  const [activeSession, setActiveSession] = useState<Session | null>(null);
  const [completedSessions, setCompletedSessions] = useState<Session[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeDurationSecs, setActiveDurationSecs] = useState(0);
  const [errorMessage, setErrorMessage] = useState("");

  const loadData = useCallback(async () => {
    setIsLoading(true);
    setErrorMessage("");

    const currentDate = getLocalDateString();
    const timezoneOffsetMinutes = getTimezoneOffsetMinutes();
    setLocalDate(currentDate);

    try {
      const data = await getTodaySessions(currentDate, timezoneOffsetMinutes);
      setActiveSession(data.activeSession ? normalizeSession(data.activeSession) : null);
      setCompletedSessions(data.completedSessions.map(normalizeSession));
    } catch (error) {
      console.error("Failed to load today's sessions:", error);
      setErrorMessage(error instanceof Error ? error.message : "Failed to load today's sessions.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | undefined;

    if (activeSession && !activeSession.clockOut) {
      const clockInMs = new Date(activeSession.clockIn).getTime();

      const updateTimer = () => {
        setActiveDurationSecs(Math.max(0, Math.floor((Date.now() - clockInMs) / 1000)));
      };

      updateTimer();
      interval = setInterval(updateTimer, 1000);
    } else {
      setActiveDurationSecs(0);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [activeSession]);

  const handleToggleShift = async () => {
    if (isProcessing) return;

    setIsProcessing(true);
    setErrorMessage("");

    try {
      const currentDate = getLocalDateString();
      const timezoneOffsetMinutes = getTimezoneOffsetMinutes();

      if (activeSession) {
        await clockOut(activeSession.id, activeSession.workDate, timezoneOffsetMinutes);
      } else {
        await clockIn(currentDate, timezoneOffsetMinutes);
      }

      await loadData();
    } catch (error) {
      console.error("Shift action failed:", error);
      setErrorMessage(error instanceof Error ? error.message : "The shift action failed. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const metrics = useMemo(() => {
    const completedRegularHours = completedSessions.reduce((total, item) => total + (item.regularHours ?? 0), 0);
    const completedOtHours = completedSessions.reduce((total, item) => total + (item.otHours ?? 0), 0);
    const completedEarned = completedSessions.reduce((total, item) => total + (item.totalEarned ?? 0), 0);
    const activeHours = activeDurationSecs / 3600;
    const completedHours = completedRegularHours + completedOtHours;

    const remainingRegularHours = Math.max(0, safeRegularShiftHours - completedHours);
    const activeRegularHours = Math.min(activeHours, remainingRegularHours);
    const activeOtHours = Math.max(0, activeHours - activeRegularHours);

    const activeRegularRate = activeSession?.appliedRegularRate ?? regularHourlyRate;
    const activeOtRate = activeSession?.appliedOtRate ?? otHourlyRate;
    const activeEstimatedEarned = activeRegularHours * activeRegularRate + activeOtHours * activeOtRate;

    const totalHours = completedHours + activeHours;
    const totalOtHours = completedOtHours + activeOtHours;
    const estimatedEarned = completedEarned + activeEstimatedEarned;
    const progressPercent = Math.min((totalHours / safeRegularShiftHours) * 100, 100);

    return {
      completedHours,
      totalHours,
      totalOtHours,
      estimatedEarned,
      progressPercent,
      isOvertime: totalHours > safeRegularShiftHours,
    };
  }, [activeDurationSecs, activeSession, completedSessions, otHourlyRate, regularHourlyRate, safeRegularShiftHours]);

  if (isLoading) {
    return (
      <div className="grid gap-5 lg:grid-cols-[1.05fr_0.95fr]">
        <div className="h-96 animate-pulse rounded-[2rem] bg-muted" />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-1">
          <div className="h-40 animate-pulse rounded-[2rem] bg-muted" />
          <div className="h-40 animate-pulse rounded-[2rem] bg-muted" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {errorMessage ? (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm font-medium text-destructive">
          {errorMessage}
        </div>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-[1.05fr_0.95fr]">
        <section className="rounded-[2rem] border border-border bg-surface p-5 shadow-sm md:p-7">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <p className="text-sm font-bold uppercase tracking-[0.18em] text-muted-foreground">
                {localDate ? formatDateLabel(localDate) : "Today"}
              </p>
              <h3 className="mt-2 text-2xl font-black tracking-tight text-foreground">
                {activeSession ? "Shift in progress" : "Ready to clock in"}
              </h3>
            </div>

            <span
              className={[
                "inline-flex w-fit items-center rounded-full px-3 py-1 text-xs font-bold uppercase tracking-[0.14em]",
                activeSession
                  ? "bg-success/10 text-success ring-1 ring-success/30"
                  : "bg-muted text-muted-foreground ring-1 ring-border",
              ].join(" ")}
            >
              {activeSession ? "Active" : "Off duty"}
            </span>
          </div>

          <div className="mt-8 rounded-[2rem] border border-border bg-muted/35 p-5 text-center sm:p-8">
            <p className="text-xs font-bold uppercase tracking-[0.24em] text-muted-foreground">
              {activeSession ? "Current shift timer" : "No active timer"}
            </p>
            <p className="mt-4 text-5xl font-black tracking-tight text-foreground tabular-nums sm:text-6xl">
              {activeSession ? formatDuration(activeDurationSecs) : "00:00:00"}
            </p>
            <p className="mt-3 text-sm text-muted-foreground">
              {activeSession
                ? `Started at ${formatTime(activeSession.clockIn)}`
                : "Tap the button below when your work starts."}
            </p>

            <button
              type="button"
              onClick={handleToggleShift}
              disabled={isProcessing}
              className={[
                "mt-7 inline-flex w-full items-center justify-center rounded-2xl px-5 py-4 text-sm font-black uppercase tracking-[0.16em] text-white shadow-sm transition active:scale-[0.99] disabled:opacity-70 sm:w-auto sm:min-w-56",
                activeSession
                  ? "bg-destructive hover:bg-destructive/90"
                  : "bg-success hover:bg-success/90",
              ].join(" ")}
            >
              {isProcessing ? "Processing..." : activeSession ? "Clock out" : "Clock in"}
            </button>
          </div>

          <div className="mt-6 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="font-semibold text-foreground">Regular shift progress</span>
              <span className="font-bold text-primary tabular-nums">
                {formatHours(metrics.totalHours)} / {formatHours(safeRegularShiftHours)}
              </span>
            </div>

            <div className="h-3 rounded-full bg-muted p-0.5">
              <div
                className={[
                  "h-full rounded-full transition-all duration-700",
                  metrics.isOvertime ? "bg-warning" : "bg-primary",
                ].join(" ")}
                style={{ width: `${metrics.progressPercent}%` }}
              />
            </div>

            {metrics.isOvertime ? (
              <p className="text-sm font-medium text-warning">Overtime has started for today.</p>
            ) : (
              <p className="text-sm text-muted-foreground">
                {formatHours(Math.max(0, safeRegularShiftHours - metrics.totalHours))} remaining before overtime.
              </p>
            )}
          </div>
        </section>

        <section className="grid gap-5 sm:grid-cols-2 lg:grid-cols-1">
          <StatCard
            label="Today hours"
            value={formatHours(metrics.totalHours)}
            note={`${completedSessions.length} completed session${completedSessions.length === 1 ? "" : "s"}`}
          />
          <StatCard
            label="Estimated pay"
            value={formatMoney(metrics.estimatedEarned, currencySymbol)}
            note="Includes active shift estimate"
          />
          <StatCard
            label="Overtime"
            value={formatHours(metrics.totalOtHours)}
            note={metrics.isOvertime ? "Currently earning OT" : "No overtime yet"}
          />
        </section>
      </div>

      <section className="rounded-[2rem] border border-border bg-surface p-5 shadow-sm md:p-6">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-lg font-black tracking-tight text-foreground">Today&apos;s sessions</h3>
            <p className="text-sm text-muted-foreground">Completed shifts for the selected local work date.</p>
          </div>

          {completedSessions.some((item) => item.autoClosed) ? (
            <span className="rounded-full bg-warning/10 px-3 py-1 text-xs font-bold uppercase tracking-[0.14em] text-warning ring-1 ring-warning/30">
              Auto-closed record
            </span>
          ) : null}
        </div>

        <div className="mt-5 divide-y divide-border overflow-hidden rounded-3xl border border-border">
          {completedSessions.length > 0 ? (
            completedSessions.map((item) => {
              const hours = (item.regularHours ?? 0) + (item.otHours ?? 0);

              return (
                <div key={item.id} className="grid gap-3 bg-muted/20 p-4 sm:grid-cols-[1fr_auto] sm:items-center">
                  <div>
                    <p className="text-sm font-bold text-foreground">
                      {formatTime(item.clockIn)} - {formatTime(item.clockOut)}
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Regular {formatHours(item.regularHours ?? 0)} · OT {formatHours(item.otHours ?? 0)}
                      {item.autoClosed ? " · Auto-closed" : ""}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 sm:justify-end">
                    <span className="rounded-full bg-surface px-3 py-1 text-xs font-bold text-foreground ring-1 ring-border tabular-nums">
                      {formatHours(hours)}
                    </span>
                    <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary ring-1 ring-primary/20 tabular-nums">
                      {formatMoney(item.totalEarned ?? 0, currencySymbol)}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="bg-muted/20 px-4 py-10 text-center">
              <p className="text-sm font-semibold text-foreground">No completed sessions yet today.</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Completed shifts will appear here after you clock out.
              </p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
